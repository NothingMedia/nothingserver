# Imports
from flask import *
from yt_dlp import YoutubeDL
import random
import string
import subprocess
import datetime
import json
import os
import requests
import sys
import time
import shutil

# Initialise Variables
app = Flask(__name__)
rootFolder = "/data/data/com.termux/files/home/storage/external-1"
storageFolder = os.path.join(rootFolder, "NothingStorage")
mediaFolder = os.path.join(rootFolder, "NothingMedia")
thumbnailsFolder = os.path.join(rootFolder, "NothingThumbnails")
playlists = []
watched_videos = []
app.secret_key = "AIzaSyAsYtcKhLdlVb3VvN9-9eMkeo7xuftzvhI"
# Functions
def createIfNotExists(path):
	if not os.path.exists(path):
		os.mkdir(path)

def downloadMetadata(link, tofolder):
	info = YoutubeDL().extract_info(link, download=False)
	metadata = {
		"title": info["title"],
		"likes": info["like_count"],
		"views": info["view_count"],
		"channel": info["channel"],
		"verified": False,
		"followers": info["channel_follower_count"],
		"uploadDate": info["upload_date"],
		"description": info["description"],
		"duration": info["duration_string"],
		"categories": info["categories"],
		"tags": info["tags"],
		"index": info["id"],
		"playlist": None,
		"currentFolder": "Home"
	}
	if "channel_is_verified" in info:
		metadata["verified"] = info["channel_is_verified"]
	json.dump(metadata, open(os.path.join(storageFolder, f"{tofolder}/[{metadata['index']}].db"), "w"), indent=2)
	response = requests.get(info["thumbnail"])
	with open(os.path.join(thumbnailsFolder, f"[{info['id']}].webp"), "wb") as pic:
		pic.write(response.content)

def downloadVideo(link, format):
	path = os.path.join(mediaFolder, "[%(id)s].mp4")
	command = ["yt-dlp", "-f", format, "--output", path, link]
	subprocess.run(command)

def remove_history(directory):
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isfile(item_path):
            os.remove(item_path)
        elif os.path.isdir(item_path):
            remove_history(item_path)
            os.rmdir(item_path)

# Server Routes (to be accesed only by frontend)
@app.route("/api/download")
def downloadRoute():
	link = request.args.get("v")
	format = request.args.get("f")
	downloadVideo(link, format)
	downloadMetadata(link, "Home")
	return link

@app.route("/api/getinfo/<id>")
def getInfo(id):
	filename = f"[{id}].db"
	folder_list = ["Home", "Playlists", "Library"]
	for folder in folder_list:
		currentFolder = f"{storageFolder}/{folder}"
		for root, dirs, files in os.walk(currentFolder):
			if filename in files:
				info = json.load(open(os.path.join(root, filename)))
	return info

@app.route("/api/resources/<name>")
def serveResources(name):
	path = os.path.join(storageFolder, name)
	end_output = []
	for root, dirs, files in os.walk(path):
		for file_name in files:
			data = json.load(open(os.path.join(root, file_name)))
			end_output.append(data)
	return jsonify(end_output)

@app.route("/api/delete/<id>")
def deleteData(id):
	template = f"[{id}]"
	filename = f"[{id}].db"
	for root, dirs, files in os.walk(storageFolder):
		if filename in files:
			filepath = os.path.join(root, filename)
			os.remove(filepath)
			os.remove(os.path.join(thumbnailsFolder, f"{template}.webp"))
			os.remove(os.path.join(mediaFolder, f"{template}.mp4"))
			os.remove(os.path.join(os.path.join(storageFolder, "Watched"), f"[{id}].db"))
			return f"Video with id: {id} deleted successfully!"

@app.route("/api/playlists")
def servePlaylists():
	global playlists
	playlists = []
	with open(os.path.join(storageFolder, "playlists.db"), "r") as file:
		playlists = json.load(file)
	return sorted(playlists)

@app.route("/api/playlists/add/<name>")
def addPlaylist(name):
	global playlists
	if not name in playlists:
		playlists = []
		with open(os.path.join(storageFolder, "playlists.db"), "r") as file:
			playlists = json.load(file) 
		playlists.append(name)
		with open(os.path.join(storageFolder, "playlists.db"), "w") as file:
			json.dump(playlists, file)
		return json.load(open(os.path.join(storageFolder, "playlists.db"), "r"))
	else:
		return playlists

@app.route("/api/playlists/delete/<name>")
def deletePlaylist(name):
	global playlists
	if name in playlists:
		data = json.load(open(os.path.join(storageFolder, "playlists.db")))
		data.remove(name)
		with open(os.path.join(storageFolder, "playlists.db"), 'w') as file:
			json.dump(data, file)
		playlists = json.load(open(os.path.join(storageFolder, "playlists.db")))
		return playlists
	else:
		return playlists

@app.route("/api/update/<id>")
def updateVideos(id):
    source = request.args.get("source")
    destination = request.args.get("destination")
    if not source == "Playlists":
        filename = f"{storageFolder}/{source}/[{id}].db"
        dest = f"{storageFolder}/{destination}/[{id}].db"
        with open(filename, "r") as file:
            data = json.load(file)
            data["playlist"] = None
            data["currentFolder"] = destination
        with open(filename, "w") as file:
            file.seek(0)
            file.truncate()
            json.dump(data, file, indent=2)
            file.seek(0)
        os.rename(filename, dest)
    else:
        filename = f"{storageFolder}/{source}/[{id}].db"
        dest = f"{storageFolder}/{destination}/[{id}].db"
        with open(filename, "r") as file:
            data = json.load(file)
            data["playlist"] = None
            data["currentFolder"] = destination
        with open(filename, "w") as file:
            file.seek(0)
            file.truncate()
            json.dump(data, file, indent=2)
            file.seek(0)
        os.rename(filename, dest)
    return "", 200

@app.route("/api/addtoplaylist/<id>")
def addToPlaylist(id):
	source = request.args.get("source")
	destination= request.args.get("destination")
	if destination in playlists:
		filename = f"{storageFolder}/{source}/[{id}].db"
		with open(filename, "r") as file:
			data = json.load(file)
		with open(filename, "w") as file:
			file.seek(0)
			data["playlist"] = destination
			data["currentFolder"] = "Playlists"
			json.dump(data, file, indent=2)
			file.truncate()
			file.seek(0)
		os.rename(filename, f"{storageFolder}/Playlists/[{id}].db")
		return f"Video Moved to {destination}", 200
	else:
		return f"Sorry! But the playlist {destination} doesn't exist..."

@app.route("/api/watch/<id>")
def serveVideo(id):
	filepath = os.path.join(mediaFolder, f"[{id}].mp4")
	return send_file(filepath, as_attachment=False)

@app.route("/api/thumbnail/<id>")
def serveThumbnail(id):
	filepath = os.path.join(thumbnailsFolder, f"[{id}].webp")
	return send_file(filepath, as_attachment=False)

@app.route("/api/files/<path:filename>")
def serveRawFiles(filename):
	filepath = os.path.join(".", filename)
	return send_file(filepath, as_attachment=False)

@app.route("/api/shutdown", methods=["POST"])
def shut_down_server():
	remove_history(os.path.join(storageFolder, "Watched"))
	os._exit(0)

@app.route("/api/watched")
def checkWatched():
	global watched_videos
	id = request.args.get("v")
	current = request.args.get("f")
	if id in watched_videos:
		return "", 200
	else:
		watched_videos.append(id)
		source = f"{storageFolder}/{current}/[{id}].db"
		destination = f"{storageFolder}/Watched/[{id}].db"
		shutil.copy(source, destination)
		return "", 200

@app.route("/api/refresh")
def refreshVideo():
	id = request.args.get("v")
	folder = request.args.get("f")
	filepath = f"{storageFolder}/{folder}/[{id}].db"
	link = f"https://www.youtube.com/watch?v={id}"
	downloadMetadata(link, folder)
	return "", 200

@app.route("/api/search")
def searchText():
    search_string = request.args.get("query")
    result_files = []
    folder_list = ["Home", "Playlists", "Library"]
    for folder in folder_list:
        currentFolder = f"{storageFolder}/{folder}"
        for root, dirs, files in os.walk(currentFolder):
            for file in files:
                if file.endswith(".db"):
                    filepath = os.path.join(root, file)
                    with open(filepath, "r") as f:
                        try:
                            data = json.load(f)
                            # Check if any of the properties contain the search string
                            if any(search_string.lower() in str(data[prop]).lower() for prop in ["title", "categories", "channel", "tags"]):
                                result_files.append(data)
                        except json.JSONDecodeError:
                            print(f"Error decoding JSON in file: {filepath}")
    return result_files

@app.route("/api/playlists/get/<name>")
def getFromPlaylist(name):
	global playlists
	result = []
	if name in playlists:
		folder_path = f"{storageFolder}/Playlists"
		for root, dirs, files in os.walk(folder_path):
			for file in files:
				path = os.path.join(root, file)
				data = json.load(open(path, "r"))
				if data["playlist"] == name:
					result.append(data)
		return result
	else:
		return "Sorry! Playlist Doesn't Exist..."

# Frontend Routes
@app.route('/', defaults={'pathname': ''})
@app.route('/<path:pathname>')
def index(pathname):
	return render_template("index.html")

# Running the Server
createIfNotExists(storageFolder)
createIfNotExists(mediaFolder)
createIfNotExists(thumbnailsFolder)
createIfNotExists(os.path.join(storageFolder, "Home"))
createIfNotExists(os.path.join(storageFolder, "Library"))
createIfNotExists(os.path.join(storageFolder, "Playlists"))
createIfNotExists(os.path.join(storageFolder, "Watched"))
remove_history(os.path.join(storageFolder, "Watched"))
if not os.path.exists(os.path.join(storageFolder, "playlists.db")):
	subprocess.run(["touch", f"{storageFolder}/playlists.db"])
	with open(os.path.join(storageFolder, "playlists.db"), "w") as playlist_file:
		write = '''
		[
		  "deafult"
		]
		'''
		playlist_file.write(write)
with open(os.path.join(storageFolder, "playlists.db"), "r") as playlist_file:
	playlists = json.load(playlist_file)
subprocess.run(["rm", "-rf", f"{mediaFolder}/*.part"])
app.run(host="0.0.0.0", port=9876, debug=True)