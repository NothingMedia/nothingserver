const rootContainer = document.querySelector(".app-root")

function shutDownRequest() {
	fetch("/api/shutdown", {
		method: "POST"
    })
}

function watchVideo(id, playlist) {
    rootContainer.innerHTML = "";
    loading()
    window.currentPlaylist = playlist
    let fetched;
    const watchDiv = document.createElement("div");
    fetch(`/api/getinfo/${id}`)
        .then(response => response.json())
        .then(info => {
            const title = info.title;
            window.currentIndex = info.index;
            window.currentFolder = info.currentFolder;
            const channel = info.channel;
            const channelIcon = checkIcon(info.verified);
            const likes = changeNum(info.likes);
            const views = changeNum(info.views);
            const uploadDate = formatDate(info.uploadDate);
            fetch(`/api/watched?v=${info.index}&f=${info.currentFolder}`);
            watchDiv.innerHTML = `
                <div class="videoCont">
                    <video src="/api/watch/${id}" class="video-player" controls autoplay></video>
                </div>
                <h2 class="title" style="font-size: 17px; margin-top: 10px;">${title}</h2>
                <div class="inline-div" style="margin-left: 2.5px;">
                    <p class="inline-meta">${views} views</p>
                    <p class="inline-meta">• ${likes} likes</p>
                    <p class="inline-meta">• ${uploadDate}</p>
                    <a class="material-icons watch_more_horiz" onclick="openOptions('${info.index}')">more_horiz</a>
                </div>
                <p style="font-family: Poppins; font-size: 17px; padding-top: 8px; padding-bottom: 8px; border-top: rgba(255, 255, 255, 0.2) solid 1px; border-bottom: rgba(255, 255, 255, 0.2) solid 1px;">
                    <i class="material-icons" style="vertical-align: -6px;">${channelIcon}</i> ${channel} 
                    <span class="inline-meta" style="font-size: 10px; vertical-align: 1px;">${changeNum(info.followers)}</span>
                </p>
            `;
            navigator.mediaSession.metadata = new MediaMetadata({
			  title: `${info.title}`,
			  artist: `${info.channel}`,
			  artwork: [
			    { src: '/api/files/icons/android-chrome-512x512.png', sizes: '512x512', type: 'image/png' }
			  ]
			});
            const playerRoot = document.createElement("div");
            if (window.currentFolder === "Playlists") {
                fetched = fetch(`/api/playlists/get/${playlist}`);
            } else {
                fetched = fetch(`/api/resources/${info.currentFolder}`);
            }
            loaded()
            fetched
                .then(response => response.json())
                .then(data => {
                    data.forEach(item => {
                        if (window.currentIndex === item.index) {
                            return;
                        }
                        const div = document.createElement("div");
                        div.classList.add("videoBlocks");
                        const imgURL = `/api/thumbnail/${item.index}`;
                        const duration = item.duration;
                        const title = item.title;
                        const channel = item.channel;
                        const views = changeNum(item.views);
                        const likes = changeNum(item.likes);
                        const daysAgo = formatDate(item.uploadDate);
                        const channelIcon = checkIcon(item.verified);
                        div.innerHTML = `
                            <a onclick="watchVideo('${item.index}', '${playlist}')">
                                <div class="imgCont">
                                    <img src="${imgURL}" class="thumbnails">
                                    <p class="vidDuration">${duration}s</p>
                                </div>
                                <div>
                                    <h2 class="title">${title}</h2>
                                </div>
                            </a>
                            <a class="material-icons more_vert" onclick="openOptions('${item.index}')">more_vert</a>
                            <div class="inline-div">
                                <p class="inline-meta">
                                    <i class="material-icons channelIcons">${channelIcon}</i> ${channel}
                                </p>
                                <p class="inline-meta">• ${views} views</p>
                                <p class="inline-meta">• ${daysAgo}</p>
                            </div>
                        `;
                        playerRoot.appendChild(div);
                    });
                    watchDiv.appendChild(playerRoot);
                });
        });
        
    rootContainer.append(watchDiv);
}

function renderVideos(folder) {
    rootContainer.innerHTML = ""
    loading()
    fetch(`/api/resources/${folder}`).then(response => response.json()).then(data => {
	    data.forEach(item => {
		    const div = document.createElement("div")
		    div.classList.add("videoBlocks")
		    const imgURL = `/api/thumbnail/${item.index}`
		    const duration = item.duration
		    const title = item.title
		    const channel = item.channel
		    const views = changeNum(item.views)
		    const likes = changeNum(item.likes)
		    const daysAgo = formatDate(item.uploadDate)
		    const channelIcon = checkIcon(item.verified)
		    div.innerHTML = `
		        <a  onclick="watchVideo('${item.index}')">
		            <div class="imgCont">
			        <img src="${imgURL}" class="thumbnails">
				    <p class="vidDuration">${duration}s</p>
				    </div>
				    <div>
				    <h2 class="title">${title}</h2>
				</a>
				<a  class="material-icons more_vert" onclick="openOptions('${item.index}')">more_vert</a>
				    <div class="inline-div">
				    <p class="inline-meta"><i class="material-icons channelIcons">${channelIcon}</i> ${channel}</p>
				    <p class="inline-meta">• ${views} views</p>
				    <p class="inline-meta">• ${daysAgo}</p>
				    </div>
				    </div>
		    `
		    rootContainer.appendChild(div)
        })
        loaded()
    })
}

function refreshVideo() {
	closeOptions()
	const id = window.optionsIndex
    const folder = window.currentFolder
	fetch(`/api/refresh?v=${id}&f=${folder}`)
}

function openOptions(id) {
	const optionsWindow = document.querySelector(".moreOptions");
    optionsWindow.style.display = "flex";
    window.optionsIndex = id;
    fetch(`/api/getinfo/${id}`).then(response => response.json()).then(info => {
    	window.optionsFolder = info.currentFolder
    })
}

function closeOptions() {
	const optionsWindow = document.querySelector(".moreOptions")
    optionsWindow.style.display = "none";
}

function deleteVideo() {
	fetch(`/api/delete/${window.optionsIndex}`).then(response => {
		renderVideos("Home")
    })
    closeOptions()
}

function openDownload() {
	const downloadWindow = document.querySelector(".downloadOptions")
    downloadWindow.style.display = "flex";
}

function closeDownload() {
	const downloadWindow = document.querySelector(".downloadOptions")
    downloadWindow.style.display = "none";
}

function downloadVideo() {
	const inputField = document.getElementById("downloadURL");
    const downLink = inputField.value;
    const format = document.getElementById("res").value;
    fetch(`/api/download?v=${downLink}&f=${format}`)
    closeDownload()
    inputField.value = "";
}

function moveVideo() {
	const id = window.optionsIndex
	const folder = window.optionsFolder
	if (folder === "Home") {
		fetch(`/api/update/${id}?source=${folder}&destination=Library`).then(response => {
			renderVideos('Home')
        })
    }
    else if (folder === "Library") {
    	fetch(`/api/update/${id}?source=${folder}&destination=Home`).then(response => {
    		renderVideos('Library')
        })
    }
    else if (folder === "Playlists") {
    	fetch(`/api/update/${id}?source=${folder}&destination=Home`).then(response => {
    	    playlistsPage()
        })
    }
    closeOptions()
}

function openSearch() {
    rootContainer.innerHTML = "";
    const searchPage = document.createElement("div");
    searchPage.classList.add("searchPage");
    searchPage.innerHTML = `
        <p class="searchPage--title">Search for videos:</p>
        <input type="text" id="searchPage--input" placeholder="Search for Something" autocomplete="off" onKeyPress="searchResults()">
        <button class="searchPage--submit" type="button" onclick="searchResults()">Search!</button>
        <div class="searchPage--results"></div>
    `;
    rootContainer.append(searchPage);
}

function searchResults() {
    const query = document.querySelector("#searchPage--input").value;
    const resultDiv = document.querySelector(".searchPage--results");
    resultDiv.innerHTML = "";
    loading()
    fetch(`/api/search?query=${query}`).then(response => response.json()).then(data => {
        data.forEach(item => {
            const div = document.createElement("div");
            div.classList.add("videoBlocks");
            const imgURL = `/api/thumbnail/${item.index}`;
            const duration = item.duration;
            const title = item.title;
            const channel = item.channel;
            const views = changeNum(item.views);
            const likes = changeNum(item.likes);
            const daysAgo = formatDate(item.uploadDate);
            const channelIcon = checkIcon(item.verified);
            div.innerHTML = `
                <a  onclick="watchVideo('${item.index}')">
                    <div class="imgCont">
                        <img src="${imgURL}" class="thumbnails">
                        <p class="vidDuration">${duration}s</p>
                    </div>
                    <div>
                        <h2 class="title">${title}</h2>
                    </a>
                    <a  class="material-icons more_vert" onclick="openOptions('${item.index}')">more_vert</a>
                    <div class="inline-div">
                        <p class="inline-meta"><i class="material-icons channelIcons">${channelIcon}</i> ${channel}</p>
                        <p class="inline-meta">• ${views} views</p>
                        <p class="inline-meta">• ${daysAgo}</p>
                    </div>
                </div>
            `;
            resultDiv.appendChild(div);
        });
        loaded()
    });
}

function playlistsPage() {
	rootContainer.innerHTML = ""
	loading()
	const addPlaylistButton = document.createElement("a")
	addPlaylistButton.innerHTML = "Create Playlist"
	addPlaylistButton.classList.add("addPlaylistButton")
	addPlaylistButton.setAttribute("onclick", "createPlaylist()")
	rootContainer.append(addPlaylistButton)
	fetch("/api/playlists").then(response => response.json()).then(info => {
		info.forEach(item => {
			const cont = document.createElement("div")
			cont.innerHTML = `
			    <a  class="playlistList" onclick="getPlaylistFrom('${item}')"><i class="material-icons playlistIcon">featured_play_list</i>${item}<a onclick="deletePlaylist('${item}')" class="deletePlaylist"><i class="material-icons deletePlaylistIcon">delete</i></a></a>
            `
            rootContainer.appendChild(cont)
        })
        loaded()
    })
}

function createPlaylist() {
	const createPlaylistDiv = document.createElement("div")
	createPlaylistDiv.innerHTML = `
	        <div class="downloadOptions createPlaylistDiv">
		    	<div class="moreOptions--window">
		    	    <div class="moreOptions--titlebar">
		    	        <span class="moreOptions--title">Create Playlist</span>
		                <button class="moreOptions--close" onclick="closeDownload()">&times;</button>
		    	    </div>
		            <div class="moreOptions--content">
		            	<input type="url" id="createPlaylistInput" placeholder="Playlist Name: "></input>
		                <a  class="moreOptions--buttons moreOptions--last createPlaylistButton" onclick="addPlaylist()"><i class="material-icons moreOptions--icons">edit</i>Create</a>
		            </div>
		    	</div>
		    </div>
	`
	rootContainer.appendChild(createPlaylistDiv)
}

function addPlaylist() {
	const input = document.querySelector("#createPlaylistInput")
	const name = input.value
	fetch(`/api/playlists/add/${name}`).then(response => {
		closeDownload();
	    playlistsPage();
    })
}

function getPlaylistFrom(list) {
	rootContainer.innerHTML = ""
	loading()
	const playlistTitle = document.createElement("p")
	rootContainer.append(playlistTitle)
    fetch(`/api/playlists/get/${list}`).then(response => response.json()).then(data => {
	    if (Object.keys(data).length === 0){
		    playlistTitle.classList.add("emptyPlaylist")
		    playlistTitle.innerHTML = "This Playlist doesn't contain any videos."
		    loaded()
        }
        else {
        	playlistTitle.classList.add("playlistTitle")
            playlistTitle.innerHTML = `<i class="material-icons playlistTitleIcon">featured_play_list</i>${list}`
            data.forEach(item => {
			    const div = document.createElement("div")
			    div.classList.add("videoBlocks")
			    const imgURL = `/api/thumbnail/${item.index}`
			    const duration = item.duration
			    const title = item.title
			    const channel = item.channel
			    const views = changeNum(item.views)
			    const likes = changeNum(item.likes)
			    const daysAgo = formatDate(item.uploadDate)
			    const channelIcon = checkIcon(item.verified)
			    div.innerHTML = `
			        <a  onclick="watchVideo('${item.index}', '${list}')">
			            <div class="imgCont">
				        <img src="${imgURL}" class="thumbnails">
					    <p class="vidDuration">${duration}s</p>
					    </div>
					    <div>
					    <h2 class="title">${title}</h2>
					</a>
					<a  class="material-icons more_vert" onclick="openOptions('${item.index}')">more_vert</a>
					    <div class="inline-div">
					    <p class="inline-meta"><i class="material-icons channelIcons">${channelIcon}</i> ${channel}</p>
					    <p class="inline-meta">• ${views} views</p>
					    <p class="inline-meta">• ${daysAgo}</p>
					    </div>
					    </div>
			    `
			    rootContainer.appendChild(div)
	        })
	loaded()
        }
    })
}

function openPlaylistList() {
    closeOptions();
    const list = document.createElement("div");
    list.classList.add("listDiv")
    list.innerHTML = `
        <div class="playlistListWindow">
            <div class="playlistListWindow--window">
                <div class="moreOptions--titlebar">
                    <span class="moreOptions--title playlistListWindow--title">Which Playlist?</span>
                    <button class="moreOptions--close" onclick="closePlaylistList()">&times;</button>
                </div>
                <div class="playlistListWindow--content">
                </div>
            </div>
        </div>
    `;
    rootContainer.append(list);
    fetch("/api/playlists")
        .then(response => response.json())
        .then(info => {
            info.forEach(item => {
                const a = document.createElement("div")
                a.innerHTML = `
                    <a onclick="selectedPlaylist('${item}', '${window.optionsIndex}')" class="playlistListWindow--items"><i class="material-icons playlistListWindow--icon">featured_play_list</i>${item}</a>
                `
                const playlistListWindow = document.querySelector(".playlistListWindow--content")
                playlistListWindow.appendChild(a)
            });
        });
}

function closePlaylistList() {
	document.querySelector(".listDiv").remove()
}

function selectedPlaylist(playlist, id) {
	closePlaylistList()
	fetch(`/api/addtoplaylist/${id}?destination=${playlist}&source=${window.optionsFolder}`).then(response => {
		renderVideos(`${window.optionsFolder}`)
    })
}

function deletePlaylist(name) {
	fetch(`/api/playlists/delete/${name}`).then(response => {
		playlistsPage()
    })
}

function playNext() {
	closeOptions()
	const id = window.optionsIndex
	const playlist = window.currentPlaylist
	const player = document.querySelector(".video-player")
	player.addEventListener("ended", () => {
		exitFullscreen(player)
		watchVideo(`${id}`, `${playlist}`)
    })
}

function exitFullscreen(element) {
    if (element.exitFullscreen) {
        element.exitFullscreen();
    } else if (element.webkitExitFullscreen) {
        element.webkitExitFullscreen();
    } else if (element.mozCancelFullScreen) {
        element.mozCancelFullScreen();
    } else if (element.msExitFullscreen) {
        element.msExitFullscreen();
    }
}