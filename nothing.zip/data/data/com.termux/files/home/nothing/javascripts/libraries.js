function formatDate(dateString) {
  const currentDate = new Date();
  const year = dateString.slice(0, 4);
  const month = dateString.slice(4, 6) - 1; // Month is zero-based in JavaScript Date object
  const day = dateString.slice(6, 8);
  const inputDate = new Date(year, month, day);

  const timeDifference = currentDate.getTime() - inputDate.getTime();
  const daysDifference = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
  const monthsDifference = Math.floor(daysDifference / 30);
  const yearsDifference = Math.floor(monthsDifference / 12);

  if (yearsDifference === 1) {
    return `1 year ago`;
  } else if (yearsDifference > 1) {
    return `${yearsDifference} years ago`;
  } else if (monthsDifference === 1) {
    return `1 month ago`;
  } else if (monthsDifference > 1) {
    return `${monthsDifference} months ago`;
  } else if (daysDifference === 1) {
    return `1 day ago`;
  } else if (daysDifference === 0) {
    return "Today";
  } else {
  	return `${daysDifference} days ago`;
  }
}

function changeNum(num) {
  if (num < 1000) return num.toString();
  if (num < 1000000) return (num / 1000).toFixed(1) + 'K';
  if (num < 1000000000) return (num / 1000000).toFixed(1) + 'M';
  return (num / 1000000000).toFixed(1) + 'B';
}

function checkIcon(value) {
	if (value) {
		return "verified"
    }
    else {
    	return "account_circle"
    }
}

function loading() {
	const div = document.createElement("div")
	div.classList.add("loader")
	div.innerHTML = "<div class='loader'></div>"
	document.querySelector(".app-root").appendChild(div)
}

function loaded() {
	document.querySelector(".loader").remove()
}